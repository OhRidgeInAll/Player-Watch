package playerwatch;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author micha
 */
public class Playerwatch extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //launch the JavaFX application
        launch(args);
    }

    TextField txtBattleTag;
    Label loginError;
    Stage primaryStage;

    @Override
    public void start(Stage primaryStage) throws Exception {

        this.primaryStage = primaryStage;

        //  generalScene.getStylesheets().addAll(this.getClass()
        //        .getResource("PlayerwatchCSS.css").toExternalForm());

        Scene scene = loginScene();

        //set the Scene, Tite, and Icon of the primary stage, do not allow resize
        primaryStage.setScene(scene);
        primaryStage.setTitle("Playerwatch");
        primaryStage.getIcons().add(new Image("playerwatch/overwatchLogo.png"));
        primaryStage.setResizable(false);
        primaryStage.show();

    }

    private Scene loginScene() {

        //pane for login screen
        BorderPane loginPane = new BorderPane();
        loginPane.setId("loginPane");

        setLoginCenter(loginPane);
        setLoginBottom(loginPane);

        //scene of the login pane
        Scene loginScene = new Scene(loginPane, 380, 380);
        loginScene.getStylesheets().addAll(this.getClass()
                .getResource("PlayerwatchCSS.css").toExternalForm());

        //focus on the pane to remove focus from txtBattleTag
        loginPane.requestFocus();

        return loginScene;
    }
    
    private Scene generalScene(){
        
        //pane for General Stats screen
        BorderPane generalPane = new BorderPane();
        generalPane.setId("generalPane");

        setGeneralCenter(generalPane);

        Scene generalScene = new Scene(generalPane, 400, 400);
        
        
        return generalScene;
    }

    //center for login pane
    private void setLoginCenter(BorderPane main) {

        GridPane centerPane = new GridPane();
        centerPane.getColumnConstraints().add(new ColumnConstraints(100));
        centerPane.getRowConstraints().add(new RowConstraints(150));
        
        //create Textfield for Battle Tag, set column count
        txtBattleTag = new TextField();
        txtBattleTag.setPrefColumnCount(17);
        txtBattleTag.setPromptText("Enter a Battle.net ID");
        txtBattleTag.setId("BattleTag");
        txtBattleTag.setMaxWidth(200);
        
        
        
        GridPane.setConstraints(txtBattleTag, 2, 2);
        
        Button btnGeneralScene = new Button("Login");
        btnGeneralScene.setOnAction((ActionEvent e) -> {
            primaryStage.setScene(generalScene());
        });
        GridPane.setConstraints(btnGeneralScene, 4, 2);
        
        

        centerPane.getChildren().addAll(txtBattleTag, btnGeneralScene);

        //add BattleTag textfield to center pane
        main.setCenter(centerPane);

    }

    //bottom for login pane
    private void setLoginBottom(BorderPane main) {
        //label for invalid Battle.net ID input from user
        loginError = new Label("Entered an invalid Battle.net ID");
        loginError.setId("loginError");
        BorderPane.setAlignment(loginError, Pos.CENTER);

        main.setBottom(loginError);
    }

    private void setGeneralCenter(BorderPane main) {

        //HBox to contain center elements
        StackPane stackLabelPane = new StackPane();

        //VBox to contain name, hero stats labels
        VBox vBox = new VBox(10);

        //Hboxes to contain labels with stats
        HBox mostPlayHbox = new HBox(10);
        HBox winPercentHbox = new HBox(10);
        HBox achieveHbox = new HBox(10);
        HBox soloKillsHbox = new HBox(10);
        HBox elimHbox = new HBox(10);
        HBox healingHbox = new HBox(10);

        //labels of names of stats
        Label battleNetName = new Label("Name Variable");
        Label mostPlay = new Label("Most Played Hero: ");
        Label winPercent = new Label("Win Percentage");
        Label achievements = new Label("Achievements");
        Label eliminations = new Label("Total Eliminations: ");
        Label soloKills = new Label("Total Solo Kills: ");
        Label healingDone = new Label("Healing Done: ");

        //labels for variables of stats
        Label mostPlayV = new Label("mostPlayV");
        Label winPercentV = new Label("winPercentV");
        Label achievementsV = new Label("achievmentsV");
        Label eliminationsV = new Label("eliminationsV");
        Label soloKillsV = new Label("soloKillsV");
        Label healingDoneV = new Label("healingDoneV");

        //add labels to corresponding Hbox
        mostPlayHbox.getChildren().addAll(mostPlay, mostPlayV);
        winPercentHbox.getChildren().addAll(winPercent, winPercentV);
        achieveHbox.getChildren().addAll(achievements, achievementsV);
        soloKillsHbox.getChildren().addAll(soloKills, soloKillsV);
        elimHbox.getChildren().addAll(eliminations, eliminationsV);
        healingHbox.getChildren().addAll(healingDone, healingDoneV);

        //add Hboxes to main Vbox
        vBox.getChildren().addAll(battleNetName, mostPlayHbox, winPercentHbox,
                achieveHbox, soloKillsHbox, elimHbox, healingHbox);

        StackPane.setMargin(vBox, new Insets(50));
        stackLabelPane.getChildren().add(vBox);

        main.setCenter(stackLabelPane);

    }

}
